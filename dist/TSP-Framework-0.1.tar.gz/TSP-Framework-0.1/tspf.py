#!/usr/bin/python
import sys
from src.Main import *

Main(sys.argv)