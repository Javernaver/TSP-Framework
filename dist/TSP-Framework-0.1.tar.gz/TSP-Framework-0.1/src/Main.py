


class Main():
    def __init__(self, args) -> None:
        print(args)
